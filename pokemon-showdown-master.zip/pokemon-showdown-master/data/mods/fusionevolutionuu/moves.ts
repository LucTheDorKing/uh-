export const Moves: {[moveid: string]: ModdedMoveData} = {
	psychoboost: {
		inherit: true,
		isNonstandard: null,
	},
	hyperspacehole: {
		inherit: true,
		isNonstandard: null,
	},
};
