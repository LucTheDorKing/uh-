export const Scripts: ModdedBattleScriptsData = {
	inherit: 'gen8',
};
